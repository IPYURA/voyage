import React, { useState } from "react";
import "./App.css";
import styled from "styled-components";
import DataView from "./components/DataView";
import InputContainer from "./components/InputContainer";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  width: 100%;
  background: #eee;
`;

const mockup = [
  "리액트 공부하기",
  "쇼핑몰 만들기",
  "넷플릭스 만들기",
  "으아아악",
];

function App() {
  const [todoList, setTodoList] = useState(mockup);
  const [toDo, setTodo] = useState("");

  //기존 값에 신규 toDo 값을 가지고 오는 함수
  const onAdd = (todo: string) => {
    if (toDo === "") return;
    setTodoList([...todoList, toDo]); //불변성의 법칙
    setTodo(""); //빈 배열로 초기화하기
  };

  const onDelete = (todo: string) => {
    setTodoList(todoList.filter((item) => item !== todo));
  };

  return (
    <Container>
      <DataView toDoList={todoList} onDelete={onDelete} />
      <InputContainer toDo={toDo} setTodo={setTodo} onAdd={onAdd} />
    </Container>
    //showToDoInput이 true일 때만 <TodoInput> 출력하기
    //showToDoInput을 반전시키는 기능을 넣어 스위치 역할을 부여
  );
}

export default App;
