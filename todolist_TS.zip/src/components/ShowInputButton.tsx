import React from "react";
import Button from "./Button";
import styled from "styled-components";

interface props {
  show: boolean;
  onClick: () => void;
}

const Container = styled.div`
  position: absolute;
  right: 40px;
  bottom: 40px;
  z-index: 1;
`;

const ShowInputButton = ({ show, onClick }: props) => {
  return (
    <Container>
      <Button
        label={show ? "닫기" : "할 일 추가"}
        color={show ? "#304ffe" : undefined}
        onClick={onClick}
      />
    </Container>
  );
};
//onClick 함수를 통해 전체를 덮게 설계한 input태그가 나와야 한다.

export default ShowInputButton;
