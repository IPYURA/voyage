import React from "react";
import styled from "styled-components";

interface props {
  label: string;
  onClick?: () => void;
  color?: string;
}

const Container = styled.button`
  cursor: pointer;
  color: #fff;
  background: ${(props) => props.color};
  border: none;
  border-radius: 4px;
  padding: 8px 16px;
  &:hover {
    opacity: 0.8;
  }
  &:active {
    box-shadow: inset 5px 5px 5px rgba(0, 0, 0, 0.2);
  }
`;

//color값이 없을 경우, default값으로 #ff5722을 갖는다.
const Button = ({ label, onClick, color = "#ff5722" }: props) => {
  return (
    <Container color={color} onClick={onClick}>
      {label}
    </Container>
  );
  //onclick () => console.log("test")였음 원래
};

export default Button;
